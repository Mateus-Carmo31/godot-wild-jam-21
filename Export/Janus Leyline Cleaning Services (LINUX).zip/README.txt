Janus Leyline Cleaning Services

A Game by TheWandererBR.

---------- Usage Notes -------------

Windows: Make sure the .exe and .pck files are in the same folder!

----------- Save Files -------------

The game's save files are normally located in:

Windows: %APPDATA%/Roaming/Godot/app_userdata/Janus Leyline Cleaning
Linux and OSX: ~/.local/share/godot/app_userdata/Janus Leyline Cleaning

Just delete the janus_leyline.save file to remove your save!
